class Setting():

    def __init__(self):
        # Velocidad
        self.ship_speed = 2

        #Velocidad de la bala
        self.bullet_speed = 4